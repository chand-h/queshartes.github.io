Fly through different renderings of the Mandelbrot set live.
 When you find somewhere nice, render a high resolution image.

Use settings.txt to customize window size and output resolution.
 Note, output resolution is directly scaled from the live window resolution,
 so enter 2 for 2x, 10 for 10x, etc... No decimals or negatives.
 You can also set a custom output path for the image file.

////////////////////////////////////////////////////////////////////////////

CONTROLS:

UP	->	zoom in
DOWN	->	zoom out

LEFT	->	speed up
RIGHT	->	slow down
	
W,A,S,D ->  	move around
	
E	-> 	hit the brakes
	
O	->  	decrease iterations (fine)
P	->  	increase iterations (fine)
K	->  	decrease iterations (coarse)
L	->  	increase iterations (coarse)
	
J	->  	set iterations to 30 (kill lag) 
	
	Play around with these: 
		{
Z	->  	change colors
X 	->      toggle black center

		these below do not work on all color modes
R	->	smooth out color gradient
T	->	opposite
F	->	decrease color offset
G	-> 	increase color offset
		}

////////////////////////////////////////////////////////////////////////////
C + V	->  	CAPTURE SCREEN
            	*.ppm file can be opened with GIMP for free: 			https://www.gimp.org/

	     	*or other good image tools like photoshop
				

V + B   ->  	CAPTURE SCREEN AT 10x ITERATIONS

C + B   ->  	CAPTURE SCREEN AT 100x ITERATIONS


////////////////////////////////////////////////////////////////////////////
ESC	->	close app

Q	->	display debug information



